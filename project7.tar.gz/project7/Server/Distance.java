/**
 * Project 7 - Safe Walf - Distance
 * calculate the distance between two places
 *
 * @author Lanlan Wang
 *
 * @recitation 01 (Azarmi, Mehdi )
 *
 * @date November 25, 2012
 *
 */

public class Distance {
	
	/**
	 * store distance between 2 places into a 2D array
	 */
	
	private int distance[][] = new int[][]{
			{0, 8, 6, 5, 4},
			{8, 0, 4, 2, 5},
			{6, 4, 0, 3, 1},
			{5, 2, 3, 0, 7},
			{4, 5, 1, 7, 0},
	};
	
	/**
	 * an array store locations
	 */
	
	private String locations[] = new String[]{
			"CL50 - Class of 1950 Lecture Hall",
			"EE - Electrical Engineering Building",
			"LWSN - Lawson Computer Science Building",
			"PMU - Purdue Memorial Union",
			"PUSH - Purdue University Student Health Center"
	};
	
	/**
	 * initialize building coordinate and distance
	 * i and j are coordinate of 2D array
	 * d is the distance from two places
	 */
	
	private int i=0, j=0, d=0;
	
	/**
	 * accept two parameters
	 * request: the location of requester
	 * response: the location of responder
	 * Get the distance between 2 places
	 */

	public Distance(String request, String response){
		while (!request.equals(locations[i])){
			i++;
		}
		while (!response.equals(locations[j])){
			j++;
		}
		d=distance[i][j];
	}
	
	/**
	 * Getter.
	 * 
	 * @return
	 */
	
	public int getDistance(){
		return d;
	}
}
