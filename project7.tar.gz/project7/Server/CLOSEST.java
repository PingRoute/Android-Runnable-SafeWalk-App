/**
 * Project 7 - Safe Walf - Closest Server
 * process the request and response based on the destination
 *
 * @author Yufan Huang
 *
 * @recitation 04 (Azarmi, Mehdi )
 *
 * @date November 25, 2012
 *
 */

import java.util.ArrayList;

import edu.purdue.cs.cs180.channel.Channel;
import edu.purdue.cs.cs180.channel.ChannelException;
import edu.purdue.cs.cs180.channel.MessageListener;
import edu.purdue.cs.cs180.channel.TCPChannel;


public class CLOSEST implements MessageListener {

	/**
	 * The server channel.
	 */
	private Channel channel = null;
	/**
	 * Maintains the pending requests & responses.
	 */
	private ArrayList<Message> pendingRequesters;
	private ArrayList<Message> pendingResponders;
	/**
	 * The CLOSEST server constructor only needs a port.
	 * 
	 * @param port
	 */
	public CLOSEST(int port) {
		channel = new TCPChannel(port);
		channel.setMessageListener(this);
		pendingRequesters = new ArrayList<Message>();		// initialized pending list
		pendingResponders = new ArrayList<Message>();
		System.out.println("CLOSEST Server Started Successful!");	// debuging purpose
	}

	public void messageHandler(int clientID){
		try{
			if(pendingRequesters.size()>0 && pendingResponders.size()>0){
				// get the first pending in Responders
				Message responseFirst = pendingResponders.get(0);
				pendingResponders.remove(0);
				
				// ----------- get the closest requester -----------------
				int i = 0;
				Message requestClosest = pendingRequesters.get(0);
				int distance = new Distance(requestClosest.getSubInfo1(), responseFirst.getSubInfo2()).getDistance();
				while(i<pendingRequesters.size()){
					int closest = new Distance(pendingRequesters.get(i).getSubInfo1(), responseFirst.getSubInfo2()).getDistance();
					if(closest<distance){
						distance = closest;
						requestClosest = pendingRequesters.get(i);
					}
					i++;
				}
				// -------------------- end ------------------------------
				
				// remove the closest pending from requesters
				pendingRequesters.remove(requestClosest);
				
				// send message to Requester
				channel.sendMessage("Assigned:Help Team " + responseFirst.getClientID() + 
						". Time to your location is approximately " + distance + " minute(s).",
						requestClosest.getClientID());
				
				// send message to Responder
				channel.sendMessage("Assigned:" + requestClosest.getSubInfo1() + 
						" - " + requestClosest.getSubInfo2(),
						responseFirst.getClientID());
			}
			else{
				// send searching if no one in pending list
				channel.sendMessage("Searching:", clientID);
			}
		}catch(ChannelException e){
			e.printStackTrace();
		    System.exit(1);
		}
	}
	
	
	/**
	 * Handle messages received.
	 */
	@Override
	public void messageReceived(String messageString, int clientID) {
		assert (messageString != null);
		System.out.println(clientID + ": " + messageString); // For debugging
																// only, not
																// required.
		Message message = new Message(messageString, clientID);
		switch (message.getType()) {
		case Request:
			pendingRequesters.add(message);		// add request to the pending list
			messageHandler(clientID);			// process the request
			break;
		case Response:
			pendingResponders.add(message);		// add respond to the pending list
			messageHandler(clientID);			// process the respond
			break;
		default:
			System.err.println("Unexpected message of type "
					+ message.getType());
			break;
		}
	}

}
