/**
 * Project 7 - Safe Walf - Urgency Server
 * process the request and response based on the urgency situation
 *
 * @author Yufan Huang
 *
 * @recitation 04 (Azarmi, Mehdi )
 *
 * @date November 25, 2012
 *
 */

import java.util.ArrayList;

import edu.purdue.cs.cs180.channel.Channel;
import edu.purdue.cs.cs180.channel.ChannelException;
import edu.purdue.cs.cs180.channel.MessageListener;
import edu.purdue.cs.cs180.channel.TCPChannel;


public class URGENCY implements MessageListener {

	/**
	 * The server channel.
	 */
	private Channel channel = null;
	/**
	 * Maintains the 3 different pending requests & responses.
	 */
	private ArrayList<Message> pendingEmergency;
	private ArrayList<Message> pendingUrgent;
	private ArrayList<Message> pendingNormal;
	private ArrayList<Message> pendingResponders;
	/**
	 * The URGENCY server constructor only needs a port.
	 * 
	 * @param port
	 */
	public URGENCY(int port) {
		channel = new TCPChannel(port);
		channel.setMessageListener(this);
		pendingEmergency = new ArrayList<Message>();		// initialized pending list
		pendingUrgent = new ArrayList<Message>();
		pendingNormal = new ArrayList<Message>();
		pendingResponders = new ArrayList<Message>();
		System.out.println("URGENCY Server Started Successful!");	// debuging purpose
	}
	
	/**
	 * process pending list based on urgency situation
	 * and send the list to messageHandler
	 */
	public void processInfo(int clientID){
		try{
			if(pendingEmergency.size()>0 && pendingResponders.size()>0){
				messageHandler(pendingEmergency);
			}
			else if(pendingUrgent.size()>0 && pendingResponders.size()>0){
				messageHandler(pendingUrgent);
			}
			else if(pendingNormal.size()>0 && pendingResponders.size()>0){
				messageHandler(pendingNormal);
			}
			else{
				channel.sendMessage("Searching:", clientID);
			}
		}catch(ChannelException e){
			e.printStackTrace();
		    System.exit(1);
		}
	}
	
	/**
	 * get pending requester & responder from the list 
	 * and send information to both
	 */

	public void messageHandler(ArrayList<Message> pendingList){
		try{
			// get the first pending from the processing list
			Message requestFirst = pendingList.get(0);
			pendingList.remove(0);
				
			// get the first pending in Responders
			Message responseFist = pendingResponders.get(0);
			pendingResponders.remove(0);
				
			// get the distance between 2 places
			int distance = new Distance(requestFirst.getSubInfo1(), responseFist.getSubInfo2()).getDistance();
				
			// send message to Requester
			channel.sendMessage("Assigned:Help Team " + responseFist.getClientID() + 
					". Time to your location is approximately " + distance + " minute(s).",
					requestFirst.getClientID());
				
			// send message to Responder
			channel.sendMessage("Assigned:" + requestFirst.getSubInfo1() + 
					" - " + requestFirst.getSubInfo2(),
					responseFist.getClientID());

		}catch(ChannelException e){
			e.printStackTrace();
		    System.exit(1);
		}
	}
	
	
	/**
	 * Handle messages received.
	 */
	@Override
	public void messageReceived(String messageString, int clientID) {
		assert (messageString != null);
		System.out.println(clientID + ": " + messageString); // For debugging
																// only, not
																// required.
		Message message = new Message(messageString, clientID);
		switch (message.getType()) {
		case Request:
			// add to the specific list based on urgency situation
			if(message.getSubInfo2().equals("Emergency")){
				pendingEmergency.add(message);
			}
			else if(message.getSubInfo2().equals("Urgent")){
				pendingUrgent.add(message);
			}
			else if(message.getSubInfo2().equals("Normal")){
				pendingNormal.add(message);
			}
			processInfo(clientID);			// process the request
			break;
		case Response:
			pendingResponders.add(message);		// add respond to the pending list
			processInfo(clientID);			// process the respond
			break;
		default:
			System.err.println("Unexpected message of type "
					+ message.getType());
			break;
		}
	}

}
