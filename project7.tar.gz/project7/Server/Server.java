/**
 * Project 7 - Safe Walf - Server
 * the Server part of program, start server based on the parameter
 *
 * @author Yufan Huang
 *
 * @recitation 04 (Azarmi, Mehdi )
 *
 * @date November 25, 2012
 *
 */

public class Server {

	/**
	 * check whether parameters are appropriate
	 * and start certain server based on the parameter
	 */
	
	public static void main(String[] args) {	
		if(args.length==0 || args.length==1 || args.length>2){
			startFailed();
			System.exit(1);
		}
		if(args[1].equalsIgnoreCase("FCFS")){
			new FCFS(Integer.parseInt(args[0]));
		}
		else if(args[1].equalsIgnoreCase("CLOSEST")){
			new CLOSEST(Integer.parseInt(args[0]));
		}
		else if(args[1].equalsIgnoreCase("URGENCY")){
			new URGENCY(Integer.parseInt(args[0]));
		}
		else{
			startFailed();
			System.exit(1);
		}
		
	}
	
	/**
	 * Console information when sever start field
	 */
	
	public static void startFailed(){
		System.out.println("Server Start Field, Please try again!");
		System.out.println("");
		System.out.println("Server <port_number> <scheduling_algorithm>");
		System.out.println("");
		System.out.println("port_number:" + "\t\t" + "Server Port Number");
		System.out.println("scheduling_algorithm:" + "\t" + "<FCFS> or <CLOSEST> or <URGENCY>");
	}
}