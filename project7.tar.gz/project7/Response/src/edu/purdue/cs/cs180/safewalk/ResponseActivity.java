/**
 * Project 7 - Safe Walf - Response
 * the Response part of the program, including GUI and sending message
 *
 * @author Yu Ding
 *
 * @recitation 01 (Azarmi, Mehdi )
 *
 * @date November 25, 2012
 *
 */

package edu.purdue.cs.cs180.safewalk;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import edu.purdue.cs.cs180.channel.ChannelException;
import edu.purdue.cs.cs180.channel.MessageListener;
import edu.purdue.cs.cs180.channel.TCPChannel;

public class ResponseActivity extends Activity implements MessageListener {

	TCPChannel channel = null;
	Handler mHandler = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_response);

		// the ready button.
		final Button button = (Button) findViewById(R.id.ready_button);
		final TextView status = (TextView) findViewById(R.id.status_textview);
		
		// the locations drop down box
		final Spinner locations = (Spinner) findViewById(R.id.locations_spinner);

		//TODO: add channel initialization code.
		String hostname = getResources().getString(R.string.host_name);
		int port = Integer.parseInt(getResources().getString(R.string.port_number)); 
		try {
			channel = new TCPChannel(hostname, port);
			channel.setMessageListener(this);                    
		} catch (ChannelException e) {
			e.printStackTrace();
			System.exit(1);
		}  
		
		// A handler is needed since the message received is called from a
		// different Thread, and only the main thread can update the UI.
		// As a workaround, we create a handler in the main thread that displays
		// whatever it receives from the message received.
		mHandler = new Handler() {
			@Override
			public void handleMessage(android.os.Message msg) {
				Message safeWalkMessage = (Message) msg.obj;
				//TODO: handle received message.
				switch (safeWalkMessage.getType()) {
				case Assigned:
					status.setText("Assigned: " + safeWalkMessage.getInfo());
					button.setEnabled(true);
					locations.setEnabled(true);
					break;
				case Searching:
					status.setText("Searching");
					break;
				default:
					System.err.println("Unexpected message of type "
					+ safeWalkMessage.getType());
					break;
				}
			}
		};

		// The on click event.
		button.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Spinner locations = (Spinner) findViewById(R.id.locations_spinner);
				String selectedItem = (String) locations.getSelectedItem();
				button.setEnabled(false);
				locations.setEnabled(false);
				//TODO: send a message to the server.
				status.setText("Sending Request");
				try {
					channel.sendMessage(new Message(Message.Type.Response,
					"Help Team " + channel.getID() + "|" + selectedItem, channel.getID()).toString());
				} catch (ChannelException e1) {
					e1.printStackTrace();
					System.exit(1);
				}
			}
		});
	}

	@Override
	public void messageReceived(String message, int clientID) {
		// Create a handler message, and send it to the Main Thread.
		Message safeWalkMessage = new Message(message, clientID);
		android.os.Message msg = new android.os.Message();
		msg.obj = safeWalkMessage;
		mHandler.sendMessage(msg);
	}

	/**
	 * Close the application if sent to the background.
	 */
	@Override
	protected void onPause() {
	    super.onPause();
	    System.exit(0);
	}
}
